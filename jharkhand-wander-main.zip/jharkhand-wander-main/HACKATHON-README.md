# 🏔️ Jharkhand Tourism Web App - SIH Hackathon Project

A comprehensive tourism web application showcasing the beautiful destinations of Jharkhand, India. Built for the Smart India Hackathon (SIH) on the theme "Increase Jharkhand Tourism".

## 🎯 Project Overview

This web application provides tourists with complete information about Jharkhand's destinations including:
- **Famous tourist places** with detailed descriptions and images
- **Transportation options** (bus, train, cab, walking)
- **Hotels and accommodation** with price ranges and amenities
- **Local food and cuisine** recommendations
- **Interactive maps** with location markers
- **Search functionality** to find specific places

## ✨ Features

### 🏞️ Tourist Places
- 10+ famous destinations including Hundru Falls, Betla National Park, Ranchi Hill
- High-quality images and detailed descriptions
- Visiting hours, entry fees, and best time to visit
- Location coordinates for mapping

### 🚗 Transportation
- Multiple transport options for each destination
- Route information, duration, and costs
- Frequency of available services

### 🏨 Accommodation
- Hotels, hostels, guesthouses, and resorts
- Price ranges and star ratings
- Amenities and contact information
- Distance from tourist attractions

### 🍛 Local Cuisine
- Traditional Jharkhand dishes like Litti Chokha, Handia, Dhuska
- Vegetarian and non-vegetarian options
- Cost information and where to find them
- Specialty and regional indicators

### 🗺️ Interactive Features
- OpenStreetMap integration with custom markers
- Search functionality across all places
- Responsive design for mobile and desktop
- Beautiful, nature-inspired UI design

## 🛠️ Technology Stack

### Frontend (Current Implementation)
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Leaflet** for interactive maps
- **Lucide React** for icons
- **React Router** for navigation
- **Vite** for development

### Backend (Recommended)
- **FastAPI** for REST API
- **SQLite** for database
- **Pydantic** for data validation
- **Uvicorn** for ASGI server

## 🚀 Quick Start

### Frontend (Currently Running)
The React frontend is already set up and running with:
- Beautiful homepage with hero section
- Place detail pages with tabs
- Search functionality
- Interactive maps
- Sample data for 10+ places

### Backend Setup (Optional)
Follow the `backend-api-guide.md` for setting up the FastAPI backend:

```bash
# Create backend directory
mkdir backend && cd backend

# Install Python dependencies
pip install fastapi uvicorn sqlite3 pydantic

# Create the backend files as per the guide
# Run the server
uvicorn main:app --reload --port 8000
```

## 📊 Sample Dataset

### Tourist Places (10 locations)
1. **Ranchi Hill** - Hill Station with temple complex
2. **Hundru Falls** - 98m high waterfall
3. **Betla National Park** - Wildlife sanctuary with tigers
4. **Jonha Falls** - Beautiful waterfall with caves
5. **Deoghar Temple** - Sacred Jyotirlinga pilgrimage site
6. **Netarhat** - Queen of Chotanagpur hill station
7. **Rock Garden Ranchi** - Artificial lake and gardens
8. **Jagannath Temple** - Replica of Puri temple
9. **Patratu Valley** - Scenic valley with dam views
10. **Hazaribagh National Park** - Wildlife sanctuary

### Hotels & Accommodation (50+ entries)
- Resorts, hotels, hostels, guesthouses
- Price ranges from ₹800 to ₹5,000
- Various amenities and locations

### Transportation Options
- Bus routes with timings and costs
- Train connections to major cities
- Cab services with pricing
- Walking distances for nearby attractions

### Local Foods (50+ dishes)
- **Litti Chokha** - Traditional stuffed wheat balls
- **Handia** - Rice beer from tribal communities
- **Dhuska** - Deep-fried rice and lentil bread
- **Rugra** - Traditional mushroom curry
- **Tilkut** - Sesame and jaggery sweet
- And many more regional specialties

## 🎨 Design System

### Color Palette
- **Primary**: Forest Green (`hsl(150 65% 25%)`) - Representing Jharkhand's forests
- **Secondary**: Sunset Orange (`hsl(25 85% 60%)`) - Natural warmth
- **Accent**: Earth Brown (`hsl(25 45% 45%)`) - Tribal heritage
- **Nature gradients** for hero sections and cards

### Typography & Layout
- Clean, modern design with nature-inspired elements
- Card-based layouts for easy scanning
- Responsive grid system
- Beautiful image galleries

## 🗺️ API Endpoints (Backend)

```
GET /places              # List all tourist places
GET /place/{id}          # Get specific place details  
GET /search?q=query      # Search places by keyword
GET /categories          # Get all place categories
GET /stats              # Get data statistics
```

## 📱 Demo Features

### Homepage
- Stunning hero section with Jharkhand imagery
- Featured destinations grid
- Real-time search functionality
- Call-to-action sections

### Place Detail Pages
- Tabbed interface (About, Transport, Hotels, Food)
- Interactive maps with markers
- Quick info sidebar
- Beautiful image galleries

### Search & Navigation
- Instant search across all content
- Category filtering
- Responsive navigation
- Mobile-optimized interface

## 🏆 Hackathon Readiness

### ✅ Complete Features
- [x] Frontend React application
- [x] 10+ tourist destinations with complete data
- [x] Interactive maps integration
- [x] Search functionality
- [x] Responsive design
- [x] Beautiful UI/UX
- [x] Sample datasets
- [x] API architecture documentation

### 🚀 Demo Script
1. **Homepage**: Show beautiful hero section and search
2. **Place Cards**: Demonstrate responsive grid and information
3. **Detail Pages**: Navigate to place detail with tabs
4. **Maps**: Show interactive mapping functionality  
5. **Search**: Live search demonstration
6. **Mobile**: Show responsive design

### 📈 Scalability
- Modular component architecture
- TypeScript for type safety
- Efficient state management
- Optimized images and assets
- SEO-friendly routing

## 🎯 Impact & Benefits

### For Tourists
- **Easy Discovery**: Find hidden gems in Jharkhand
- **Complete Information**: All travel details in one place
- **Cost Planning**: Transparent pricing for all services
- **Cultural Experience**: Authentic local food recommendations

### For Local Economy
- **Tourism Boost**: Increased visibility for local attractions
- **Business Support**: Hotel and restaurant promotion
- **Employment**: Growth in tourism-related services
- **Cultural Preservation**: Showcasing tribal heritage and traditions

## 🔮 Future Enhancements

- **User Accounts**: Trip planning and favorites
- **Booking Integration**: Direct hotel and transport booking
- **Reviews & Ratings**: Community-driven content
- **Mobile App**: Native iOS/Android applications
- **AR/VR**: Virtual tour experiences
- **Multi-language**: Support for local languages

---

**Built with ❤️ for Jharkhand Tourism | SIH Hackathon 2024**

This project demonstrates the power of modern web technologies in promoting regional tourism and supporting local communities. The combination of beautiful design, comprehensive information, and user-friendly interface makes it a perfect solution for increasing Jharkhand tourism.