# FastAPI Backend Guide for Jharkhand Tourism App

This guide shows how to create the FastAPI backend to complement the React frontend.

## Backend Structure

```
backend/
├── main.py
├── models.py
├── database.py
├── data/
│   ├── places.json
│   ├── hotels.json
│   └── transport.json
├── requirements.txt
└── README.md
```

## 1. Requirements (requirements.txt)

```txt
fastapi==0.104.1
uvicorn==0.24.0
sqlite3
pydantic==2.5.0
python-multipart==0.0.6
```

## 2. Database Models (models.py)

```python
from pydantic import BaseModel
from typing import List, Optional

class TransportOption(BaseModel):
    id: str
    type: str  # bus, train, cab, walking
    route: str
    duration: str
    cost: str
    frequency: str

class Hotel(BaseModel):
    id: str
    name: str
    type: str  # hotel, hostel, guesthouse, resort
    price_range: str
    rating: float
    amenities: List[str]
    distance: str
    contact: str

class LocalFood(BaseModel):
    id: str
    name: str
    description: str
    cost: str
    where_to_find: str
    is_vegetarian: bool
    specialty: bool

class TouristPlace(BaseModel):
    id: str
    name: str
    category: str
    description: str
    image: str
    latitude: float
    longitude: float
    visiting_hours: str
    entry_fee: str
    best_time_to_visit: str
    highlights: List[str]
    transport: List[TransportOption]
    hotels: List[Hotel]
    foods: List[LocalFood]

class PlaceResponse(BaseModel):
    places: List[TouristPlace]
    total: int
```

## 3. Main FastAPI Application (main.py)

```python
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
import json
import sqlite3
from models import TouristPlace, PlaceResponse

app = FastAPI(
    title="Jharkhand Tourism API",
    description="API for Jharkhand Tourism Places, Hotels, Transport and Food",
    version="1.0.0"
)

# Enable CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],  # React dev servers
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load sample data
def load_sample_data():
    with open('data/places.json', 'r') as f:
        return json.load(f)

places_data = load_sample_data()

@app.get("/")
async def root():
    return {
        "message": "Jharkhand Tourism API",
        "version": "1.0.0",
        "endpoints": ["/places", "/place/{id}", "/search"]
    }

@app.get("/places", response_model=PlaceResponse)
async def get_all_places(
    category: Optional[str] = Query(None, description="Filter by category"),
    limit: int = Query(20, description="Number of places to return")
):
    """Get all tourist places with optional filtering"""
    filtered_places = places_data
    
    if category:
        filtered_places = [p for p in places_data if p['category'].lower() == category.lower()]
    
    return PlaceResponse(
        places=filtered_places[:limit],
        total=len(filtered_places)
    )

@app.get("/place/{place_id}", response_model=TouristPlace)
async def get_place_by_id(place_id: str):
    """Get detailed information about a specific place"""
    place = next((p for p in places_data if p['id'] == place_id), None)
    
    if not place:
        raise HTTPException(status_code=404, detail="Place not found")
    
    return place

@app.get("/search", response_model=PlaceResponse)
async def search_places(
    q: str = Query(..., description="Search query"),
    limit: int = Query(10, description="Number of results to return")
):
    """Search places by name, category, or description"""
    query = q.lower()
    
    filtered_places = [
        place for place in places_data
        if (query in place['name'].lower() or 
            query in place['category'].lower() or 
            query in place['description'].lower())
    ]
    
    return PlaceResponse(
        places=filtered_places[:limit],
        total=len(filtered_places)
    )

@app.get("/categories")
async def get_categories():
    """Get all available categories"""
    categories = list(set([place['category'] for place in places_data]))
    return {"categories": categories}

@app.get("/stats")
async def get_stats():
    """Get basic statistics about the data"""
    return {
        "total_places": len(places_data),
        "categories": len(set([place['category'] for place in places_data])),
        "total_hotels": sum(len(place['hotels']) for place in places_data),
        "total_foods": sum(len(place['foods']) for place in places_data)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

## 4. Sample Data (data/places.json)

```json
[
  {
    "id": "1",
    "name": "Ranchi Hill",
    "category": "Hill Station",
    "description": "A scenic hill station offering panoramic views of Ranchi city.",
    "image": "https://example.com/ranchi-hill.jpg",
    "latitude": 23.3441,
    "longitude": 85.3096,
    "visiting_hours": "6:00 AM - 6:00 PM",
    "entry_fee": "Free",
    "best_time_to_visit": "October to March",
    "highlights": ["Temple complex", "City views", "Sunset point"],
    "transport": [
      {
        "id": "t1",
        "type": "bus",
        "route": "Ranchi Main Bus Stand to Ranchi Hill",
        "duration": "30 minutes",
        "cost": "₹15-25",
        "frequency": "Every 20 minutes"
      }
    ],
    "hotels": [
      {
        "id": "h1",
        "name": "Hill View Resort",
        "type": "resort",
        "price_range": "₹2,500-4,000",
        "rating": 4.2,
        "amenities": ["Wi-Fi", "Restaurant", "Room Service"],
        "distance": "2 km from hill",
        "contact": "+91-651-2345678"
      }
    ],
    "foods": [
      {
        "id": "f1",
        "name": "Litti Chokha",
        "description": "Traditional wheat flour balls with vegetables",
        "cost": "₹40-80",
        "where_to_find": "Local street vendors",
        "is_vegetarian": true,
        "specialty": true
      }
    ]
  }
]
```

## 5. Running the Backend

```bash
# Install dependencies
pip install -r requirements.txt

# Run the server
python main.py

# Or with uvicorn directly
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

## 6. API Endpoints

- **GET /** - API information
- **GET /places** - Get all tourist places
- **GET /place/{id}** - Get specific place details
- **GET /search?q=query** - Search places
- **GET /categories** - Get all categories
- **GET /stats** - Get data statistics

## 7. Example API Responses

### GET /places
```json
{
  "places": [...],
  "total": 10
}
```

### GET /place/1
```json
{
  "id": "1",
  "name": "Ranchi Hill",
  "category": "Hill Station",
  ...
}
```

### GET /search?q=waterfall
```json
{
  "places": [
    {
      "id": "2",
      "name": "Hundru Falls",
      "category": "Waterfall",
      ...
    }
  ],
  "total": 1
}
```

## 8. Integration with React Frontend

Update your React app to use the backend API:

```typescript
// In your React app
const API_BASE_URL = 'http://localhost:8000';

export const fetchPlaces = async () => {
  const response = await fetch(`${API_BASE_URL}/places`);
  return response.json();
};

export const fetchPlaceById = async (id: string) => {
  const response = await fetch(`${API_BASE_URL}/place/${id}`);
  return response.json();
};

export const searchPlaces = async (query: string) => {
  const response = await fetch(`${API_BASE_URL}/search?q=${encodeURIComponent(query)}`);
  return response.json();
};
```

This backend provides a complete REST API for your Jharkhand tourism app with all the required endpoints!