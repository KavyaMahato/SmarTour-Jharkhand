import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { TouristPlace } from '@/data/touristPlaces';

// Fix for default markers in Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface TourismMapProps {
  places: TouristPlace[];
  center?: [number, number];
  zoom?: number;
  className?: string;
}

const TourismMap = ({ 
  places, 
  center = [23.6102, 85.2799], // Jharkhand center coordinates
  zoom = 8,
  className = "w-full h-full"
}: TourismMapProps) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  useEffect(() => {
    if (!mapRef.current) return;

    // Clean up previous map instance
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Small delay to ensure container is properly sized
    const initMap = () => {
      if (!mapRef.current) return;

      // Initialize map
      mapInstanceRef.current = L.map(mapRef.current).setView(center, zoom);

      // Add tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
      }).addTo(mapInstanceRef.current);

      // Create custom icon for tourist places
      const customIcon = L.divIcon({
        className: 'custom-marker',
        html: `
          <div style="
            background: hsl(150 65% 25%);
            border: 3px solid white;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          ">
            <div style="
              background: white;
              border-radius: 50%;
              width: 8px;
              height: 8px;
            "></div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      // Add markers for each place
      places.forEach((place) => {
        const marker = L.marker([place.latitude, place.longitude], { 
          icon: customIcon 
        }).addTo(mapInstanceRef.current!);

        // Create popup content
        const popupContent = `
          <div style="max-width: 250px;">
            <h3 style="margin: 0 0 8px 0; font-size: 16px; font-weight: bold; color: hsl(150 25% 15%);">
              ${place.name}
            </h3>
            <p style="margin: 0 0 8px 0; font-size: 12px; color: hsl(150 15% 45%); background: hsl(25 35% 85%); padding: 2px 6px; border-radius: 4px; display: inline-block;">
              ${place.category}
            </p>
            <p style="margin: 0 0 8px 0; font-size: 14px; color: hsl(150 25% 25%); line-height: 1.4;">
              ${place.description.length > 100 ? place.description.substring(0, 100) + '...' : place.description}
            </p>
            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 8px;">
              <span style="font-size: 12px; color: hsl(150 15% 45%);">
                Entry: ${place.entryFee}
              </span>
              <span style="font-size: 12px; color: hsl(25 85% 60%); font-weight: bold;">
                View Details →
              </span>
            </div>
          </div>
        `;

        marker.bindPopup(popupContent);

        // Add click event to marker
        marker.on('click', () => {
          console.log('Clicked on:', place.name);
        });
      });

      // Fit map to show all markers if multiple places
      if (places.length > 1) {
        const markers = places.map(place => 
          L.marker([place.latitude, place.longitude])
        );
        const group = L.featureGroup(markers);
        mapInstanceRef.current.fitBounds(group.getBounds().pad(0.1));
      }

      // Invalidate size to ensure proper rendering
      setTimeout(() => {
        if (mapInstanceRef.current) {
          mapInstanceRef.current.invalidateSize();
        }
      }, 100);
    };

    // Initialize map with small delay
    setTimeout(initMap, 100);

    // Cleanup function
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [places, center, zoom]);

  return (
    <div 
      ref={mapRef} 
      className={className}
      style={{ 
        minHeight: '300px', 
        height: '100%',
        width: '100%',
        position: 'relative',
        zIndex: 0
      }}
    />
  );
};

export default TourismMap;