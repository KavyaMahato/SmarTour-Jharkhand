import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin, Calendar, Clock, Star } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { TouristPlace, getAllPlaces, searchPlaces } from '@/data/touristPlaces';
import jharkhandHeroImg from '@/assets/jharkhand-hero.jpg';

const Index = () => {
  const [places, setPlaces] = useState<TouristPlace[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPlaces();
  }, []);

  const loadPlaces = async () => {
    setLoading(true);
    try {
      const data = await getAllPlaces();
      setPlaces(data);
    } catch (error) {
      console.error('Error loading places:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    setLoading(true);
    try {
      if (query.trim()) {
        const results = await searchPlaces(query);
        setPlaces(results);
      } else {
        const allPlaces = await getAllPlaces();
        setPlaces(allPlaces);
      }
    } catch (error) {
      console.error('Error searching places:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      {/* Hero Section */}
      <section className="relative overflow-hidden h-screen">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ 
            backgroundImage: `url(${jharkhandHeroImg})`,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-black/20" />
        <div className="relative container mx-auto px-4 h-full flex items-center justify-center text-center">
          <div className="max-w-4xl">
            <h1 className="mb-6 text-5xl md:text-7xl font-bold text-white drop-shadow-2xl">
              Discover Jharkhand
            </h1>
            <p className="mb-8 text-xl md:text-2xl text-white/90 max-w-3xl mx-auto leading-relaxed drop-shadow-lg">
              Explore the Land of Forests - Where waterfalls cascade through tribal heritage, 
              wildlife roams ancient forests, and spiritual journeys await
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              <Button 
                size="lg" 
                className="bg-tourism-primary text-white hover:bg-tourism-forest transition-all duration-300 text-lg px-8 py-3"
              >
                Explore Places
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm transition-all duration-300 text-lg px-8 py-3"
              >
                View Map
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Search Section */}
      <section className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <Input
              type="text"
              placeholder="Search tourist places, categories, or locations..."
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="pl-12 py-6 text-lg rounded-xl border-2 border-border/20 focus:border-tourism-primary transition-all duration-300"
            />
          </div>
        </div>
      </section>

      {/* Featured Places */}
      <section className="container mx-auto px-4 pb-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 text-foreground">
            {searchQuery ? 'Search Results' : 'Featured Destinations'}
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            From majestic waterfalls to ancient temples, discover the gems of Jharkhand
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="h-48 bg-muted rounded-t-lg" />
                <CardHeader>
                  <div className="h-6 bg-muted rounded mb-2" />
                  <div className="h-4 bg-muted rounded w-2/3" />
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded" />
                    <div className="h-4 bg-muted rounded w-3/4" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : places.length === 0 ? (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">🔍</div>
            <h3 className="text-2xl font-semibold mb-2">No places found</h3>
            <p className="text-muted-foreground mb-6">
              Try adjusting your search terms or browse all destinations
            </p>
            <Button onClick={() => handleSearch('')}>View All Places</Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {places.map((place) => (
              <Link key={place.id} to={`/place/${place.id}`} className="group">
                <Card className="overflow-hidden hover:shadow-[var(--shadow-tourism)] transition-all duration-300 group-hover:scale-105 border-border/20">
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={place.image}
                      alt={place.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                    <Badge 
                      className="absolute top-4 left-4 bg-tourism-secondary text-white border-0"
                    >
                      {place.category}
                    </Badge>
                    <div className="absolute bottom-4 left-4 text-white">
                      <div className="flex items-center space-x-1 text-sm">
                        <MapPin className="w-4 h-4" />
                        <span>Jharkhand</span>
                      </div>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-3">
                    <CardTitle className="text-xl group-hover:text-tourism-primary transition-colors duration-300">
                      {place.name}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {place.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{place.visitingHours}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4" />
                          <span>{place.bestTimeToVisit}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-tourism-primary">
                          {place.entryFee}
                        </span>
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < 4 ? 'text-yellow-400 fill-current' : 'text-gray-300'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-tourism-primary to-tourism-forest text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Explore?</h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Plan your perfect trip to Jharkhand with our comprehensive travel guide
          </p>
          <div className="flex justify-center space-x-4">
            <Button 
              size="lg" 
              className="bg-white text-tourism-primary hover:bg-white/90"
            >
              Plan Your Trip
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="border-white text-white hover:bg-white/10"
            >
              Download Guide
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;