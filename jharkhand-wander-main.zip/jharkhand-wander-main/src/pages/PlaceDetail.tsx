import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, MapPin, Clock, Calendar, IndianRupee, Car, Train, Bus, Footprints, Hotel, Utensils, Star, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { TouristPlace, getPlaceById } from '@/data/touristPlaces';
import TourismMap from '@/components/TourismMap';

const PlaceDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [place, setPlace] = useState<TouristPlace | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadPlace(id);
    }
  }, [id]);

  const loadPlace = async (placeId: string) => {
    setLoading(true);
    try {
      const data = await getPlaceById(placeId);
      setPlace(data);
    } catch (error) {
      console.error('Error loading place:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTransportIcon = (type: string) => {
    switch (type) {
      case 'bus': return <Bus className="w-5 h-5" />;
      case 'train': return <Train className="w-5 h-5" />;
      case 'cab': return <Car className="w-5 h-5" />;
      case 'walking': return <Footprints className="w-5 h-5" />;
      default: return <Car className="w-5 h-5" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-muted rounded w-32 mb-6" />
            <div className="h-96 bg-muted rounded-lg mb-8" />
            <div className="h-12 bg-muted rounded w-3/4 mb-4" />
            <div className="h-6 bg-muted rounded w-full mb-8" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="h-48 bg-muted rounded" />
              </div>
              <div className="h-48 bg-muted rounded" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!place) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🏔️</div>
          <h2 className="text-2xl font-bold mb-2">Place not found</h2>
          <p className="text-muted-foreground mb-6">The place you're looking for doesn't exist.</p>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <div className="container mx-auto px-4 py-6">
        <Link to="/" className="inline-flex items-center space-x-2 text-muted-foreground hover:text-foreground transition-colors">
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Places</span>
        </Link>
      </div>

      {/* Hero Image */}
      <div className="relative h-96 overflow-hidden">
        <img
          src={place.image}
          alt={place.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute bottom-8 left-0 right-0">
          <div className="container mx-auto px-4">
            <Badge className="mb-4 bg-tourism-secondary text-white border-0">
              {place.category}
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
              {place.name}
            </h1>
            <div className="flex items-center space-x-4 text-white/90">
              <div className="flex items-center space-x-1">
                <MapPin className="w-5 h-5" />
                <span>Jharkhand, India</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-5 h-5" />
                <span>{place.visitingHours}</span>
              </div>
              <div className="flex items-center space-x-1">
                <IndianRupee className="w-5 h-5" />
                <span>{place.entryFee}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="grid w-full grid-cols-4 mb-8">
                <TabsTrigger value="about">About</TabsTrigger>
                <TabsTrigger value="transport">Transport</TabsTrigger>
                <TabsTrigger value="hotels">Hotels</TabsTrigger>
                <TabsTrigger value="food">Food</TabsTrigger>
              </TabsList>

              {/* About Tab */}
              <TabsContent value="about" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Description</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-lg leading-relaxed text-muted-foreground">
                      {place.description}
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Highlights</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {place.highlights.map((highlight, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-tourism-primary rounded-full" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Visit Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Clock className="w-4 h-4 mr-2" />
                          Visiting Hours
                        </h4>
                        <p className="text-muted-foreground">{place.visitingHours}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <IndianRupee className="w-4 h-4 mr-2" />
                          Entry Fee
                        </h4>
                        <p className="text-muted-foreground">{place.entryFee}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2 flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          Best Time to Visit
                        </h4>
                        <p className="text-muted-foreground">{place.bestTimeToVisit}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Transport Tab */}
              <TabsContent value="transport" className="space-y-6">
                {place.transport.map((transport) => (
                  <Card key={transport.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        {getTransportIcon(transport.type)}
                        <span className="capitalize">{transport.type}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <h4 className="font-semibold mb-1">Route</h4>
                          <p className="text-muted-foreground">{transport.route}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1">Duration</h4>
                          <p className="text-muted-foreground">{transport.duration}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1">Cost</h4>
                          <p className="text-muted-foreground">{transport.cost}</p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-1">Frequency</h4>
                          <p className="text-muted-foreground">{transport.frequency}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Hotels Tab */}
              <TabsContent value="hotels" className="space-y-6">
                {place.hotels.map((hotel) => (
                  <Card key={hotel.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center space-x-2">
                            <Hotel className="w-5 h-5" />
                            <span>{hotel.name}</span>
                          </CardTitle>
                          <CardDescription className="capitalize mt-1">
                            {hotel.type} • {hotel.distance}
                          </CardDescription>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                          <span className="font-semibold">{hotel.rating}</span>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2">Price Range</h4>
                          <p className="text-tourism-primary font-semibold text-lg">
                            {hotel.priceRange}
                          </p>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Amenities</h4>
                          <div className="flex flex-wrap gap-2">
                            {hotel.amenities.map((amenity, index) => (
                              <Badge key={index} variant="secondary">
                                {amenity}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2 text-muted-foreground">
                          <Phone className="w-4 h-4" />
                          <span>{hotel.contact}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              {/* Food Tab */}
              <TabsContent value="food" className="space-y-6">
                {place.foods.map((food) => (
                  <Card key={food.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center space-x-2">
                            <Utensils className="w-5 h-5" />
                            <span>{food.name}</span>
                          </CardTitle>
                          <div className="flex items-center space-x-2 mt-2">
                            {food.isVegetarian && (
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                Vegetarian
                              </Badge>
                            )}
                            {food.specialty && (
                              <Badge className="bg-tourism-secondary text-white">
                                Specialty
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-tourism-primary">
                            {food.cost}
                          </p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">
                        {food.description}
                      </p>
                      <div>
                        <h4 className="font-semibold mb-1">Where to find</h4>
                        <p className="text-muted-foreground">{food.whereToFind}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Info */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category</span>
                  <span className="font-semibold">{place.category}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Entry Fee</span>
                  <span className="font-semibold">{place.entryFee}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Best Time</span>
                  <span className="font-semibold">{place.bestTimeToVisit}</span>
                </div>
                <Separator />
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Hours</span>
                  <span className="font-semibold">{place.visitingHours}</span>
                </div>
              </CardContent>
            </Card>

            {/* Map */}
            <Card>
              <CardHeader>
                <CardTitle>Location</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="h-64 rounded-b-lg overflow-hidden relative">
                  <TourismMap 
                    places={[place]} 
                    center={[place.latitude, place.longitude]}
                    zoom={12}
                    className="w-full h-full"
                  />
                </div>
              </CardContent>
            </Card>

            {/* CTA */}
            <Card className="bg-gradient-to-br from-tourism-primary to-tourism-forest text-white">
              <CardContent className="p-6 text-center">
                <h3 className="text-xl font-bold mb-2">Plan Your Visit</h3>
                <p className="text-white/80 mb-4">
                  Get personalized recommendations for your trip
                </p>
                <Button className="w-full bg-white text-tourism-primary hover:bg-white/90">
                  Get Travel Guide
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlaceDetail;