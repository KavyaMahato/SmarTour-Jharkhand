// Image imports
import ranchihillImg from '@/assets/ranchi-hill.jpg';
import hundrufallsImg from '@/assets/hundru-falls.jpg';
import betlanationalparkImg from '@/assets/betla-national-park.jpg';
import jonhafallsImg from '@/assets/jonha-falls.jpg';
import deoghartTempleImg from '@/assets/deoghar-temple.jpg';
import netarhatImg from '@/assets/netarhat.jpg';
import rockgardenranchImg from '@/assets/rock-garden-ranchi.jpg';
import jagannathtempleImg from '@/assets/jagannath-temple.jpg';
import patratuvalleyImg from '@/assets/patratu-valley.jpg';
import hazaribaghparkImg from '@/assets/hazaribagh-national-park.jpg';

export interface TouristPlace {
  id: string;
  name: string;
  category: string;
  description: string;
  image: string;
  latitude: number;
  longitude: number;
  visitingHours: string;
  entryFee: string;
  bestTimeToVisit: string;
  highlights: string[];
  transport: TransportOption[];
  hotels: Hotel[];
  foods: LocalFood[];
}

export interface TransportOption {
  id: string;
  type: 'bus' | 'train' | 'cab' | 'walking';
  route: string;
  duration: string;
  cost: string;
  frequency: string;
}

export interface Hotel {
  id: string;
  name: string;
  type: 'hotel' | 'hostel' | 'guesthouse' | 'resort';
  priceRange: string;
  rating: number;
  amenities: string[];
  distance: string;
  contact: string;
}

export interface LocalFood {
  id: string;
  name: string;
  description: string;
  cost: string;
  whereToFind: string;
  isVegetarian: boolean;
  specialty: boolean;
}

export const touristPlaces: TouristPlace[] = [
  {
    id: '1',
    name: 'Ranchi Hill',
    category: 'Hill Station',
    description: 'A scenic hill station offering panoramic views of Ranchi city. Known for its pleasant weather and the famous Ranchi Hill temple.',
    image: ranchihillImg,
    latitude: 23.3441,
    longitude: 85.3096,
    visitingHours: '6:00 AM - 6:00 PM',
    entryFee: 'Free',
    bestTimeToVisit: 'October to March',
    highlights: ['Temple complex', 'City views', 'Sunset point', 'Trekking trails'],
    transport: [
      {
        id: 't1',
        type: 'bus',
        route: 'Ranchi Main Bus Stand to Ranchi Hill',
        duration: '30 minutes',
        cost: '₹15-25',
        frequency: 'Every 20 minutes'
      },
      {
        id: 't2',
        type: 'cab',
        route: 'City center to Ranchi Hill',
        duration: '20 minutes',
        cost: '₹150-250',
        frequency: 'On demand'
      }
    ],
    hotels: [
      {
        id: 'h1',
        name: 'Hill View Resort',
        type: 'resort',
        priceRange: '₹2,500-4,000',
        rating: 4.2,
        amenities: ['Wi-Fi', 'Restaurant', 'Room Service', 'Parking'],
        distance: '2 km from hill',
        contact: '+91-651-2345678'
      },
      {
        id: 'h2',
        name: 'Budget Inn Ranchi',
        type: 'hostel',
        priceRange: '₹800-1,200',
        rating: 3.8,
        amenities: ['Wi-Fi', 'Shared Kitchen', 'Parking'],
        distance: '5 km from hill',
        contact: '+91-651-2345679'
      }
    ],
    foods: [
      {
        id: 'f1',
        name: 'Litti Chokha',
        description: 'Traditional wheat flour balls stuffed with sattu, served with mashed vegetables',
        cost: '₹40-80',
        whereToFind: 'Local street vendors near hill base',
        isVegetarian: true,
        specialty: true
      },
      {
        id: 'f2',
        name: 'Handia',
        description: 'Traditional rice beer popular among tribal communities',
        cost: '₹30-50',
        whereToFind: 'Tribal restaurants in the area',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '2',
    name: 'Hundru Falls',
    category: 'Waterfall',
    description: 'A spectacular waterfall cascading from a height of 98 meters, formed by the Subarnarekha River.',
    image: hundrufallsImg,
    latitude: 23.4190,
    longitude: 85.5926,
    visitingHours: '8:00 AM - 5:00 PM',
    entryFee: '₹10 per person',
    bestTimeToVisit: 'July to February',
    highlights: ['98m high waterfall', 'Swimming pool', 'Trekking', 'Photography'],
    transport: [
      {
        id: 't3',
        type: 'bus',
        route: 'Ranchi to Hundru Falls',
        duration: '1.5 hours',
        cost: '₹40-60',
        frequency: 'Every hour'
      },
      {
        id: 't4',
        type: 'cab',
        route: 'Ranchi to Hundru Falls',
        duration: '1 hour',
        cost: '₹800-1200',
        frequency: 'On demand'
      }
    ],
    hotels: [
      {
        id: 'h3',
        name: 'Waterfall Resort',
        type: 'resort',
        priceRange: '₹3,000-5,000',
        rating: 4.5,
        amenities: ['Swimming Pool', 'Restaurant', 'Nature Walks', 'Parking'],
        distance: '1 km from falls',
        contact: '+91-651-3456789'
      }
    ],
    foods: [
      {
        id: 'f3',
        name: 'Dhuska',
        description: 'Deep-fried bread made from rice and lentil batter, served with curry',
        cost: '₹25-45',
        whereToFind: 'Roadside dhabas en route',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '3',
    name: 'Betla National Park',
    category: 'National Park',
    description: 'First national park in Jharkhand, famous for tigers, elephants, and diverse wildlife.',
    image: betlanationalparkImg,
    latitude: 23.8986,
    longitude: 84.1942,
    visitingHours: '6:00 AM - 6:00 PM',
    entryFee: '₹150 per person, ₹1,500 for safari',
    bestTimeToVisit: 'November to June',
    highlights: ['Tiger safari', 'Elephant spotting', 'Bird watching', 'Ancient fort ruins'],
    transport: [
      {
        id: 't5',
        type: 'train',
        route: 'Ranchi to Daltonganj, then bus to Betla',
        duration: '4-5 hours',
        cost: '₹120-300',
        frequency: '2 trains daily'
      },
      {
        id: 't6',
        type: 'cab',
        route: 'Ranchi to Betla National Park',
        duration: '3.5 hours',
        cost: '₹2,500-3,500',
        frequency: 'On demand'
      }
    ],
    hotels: [
      {
        id: 'h4',
        name: 'Forest Lodge Betla',
        type: 'guesthouse',
        priceRange: '₹1,500-2,500',
        rating: 4.0,
        amenities: ['Restaurant', 'Guide Service', 'Nature Walks'],
        distance: 'Inside park premises',
        contact: '+91-6562-234567'
      }
    ],
    foods: [
      {
        id: 'f4',
        name: 'Rugra',
        description: 'Traditional mushroom curry popular in forest areas',
        cost: '₹60-100',
        whereToFind: 'Forest lodge restaurant',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '4',
    name: 'Jonha Falls',
    category: 'Waterfall',
    description: 'A beautiful waterfall also known as Gautamdhara, surrounded by dense forests.',
    image: netarhatImg,
    latitude: 23.2851,
    longitude: 85.4470,
    visitingHours: '7:00 AM - 6:00 PM',
    entryFee: '₹15 per person',
    bestTimeToVisit: 'June to February',
    highlights: ['43m high waterfall', 'Cave exploration', 'Meditation spot', 'Natural pool'],
    transport: [
      {
        id: 't7',
        type: 'bus',
        route: 'Ranchi to Jonha Falls',
        duration: '1 hour',
        cost: '₹30-50',
        frequency: 'Every 45 minutes'
      }
    ],
    hotels: [
      {
        id: 'h5',
        name: 'Nature Stay Jonha',
        type: 'hotel',
        priceRange: '₹2,000-3,000',
        rating: 3.9,
        amenities: ['Restaurant', 'Wi-Fi', 'Room Service'],
        distance: '3 km from falls',
        contact: '+91-651-4567890'
      }
    ],
    foods: [
      {
        id: 'f5',
        name: 'Pitha',
        description: 'Traditional rice cake with jaggery filling',
        cost: '₹20-40',
        whereToFind: 'Local vendors near falls',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '5',
    name: 'Deoghar Temple',
    category: 'Religious',
    description: 'One of the twelve Jyotirlingas, Baidyanath Dham is a major pilgrimage site.',
    image: jagannathtempleImg,
    latitude: 24.4854,
    longitude: 86.6957,
    visitingHours: '4:00 AM - 9:00 PM',
    entryFee: 'Free (Donations welcome)',
    bestTimeToVisit: 'October to March',
    highlights: ['Jyotirlinga temple', 'Spiritual significance', 'Annual fair', 'Ancient architecture'],
    transport: [
      {
        id: 't8',
        type: 'train',
        route: 'Ranchi to Jasidih, then local transport',
        duration: '6-7 hours',
        cost: '₹200-500',
        frequency: 'Multiple trains daily'
      }
    ],
    hotels: [
      {
        id: 'h6',
        name: 'Pilgrims Inn Deoghar',
        type: 'hotel',
        priceRange: '₹1,200-2,000',
        rating: 4.1,
        amenities: ['Restaurant', 'Temple View', 'Parking'],
        distance: '500m from temple',
        contact: '+91-6432-234567'
      }
    ],
    foods: [
      {
        id: 'f6',
        name: 'Tilkut',
        description: 'Sweet made from sesame seeds and jaggery, popular during winters',
        cost: '₹15-30',
        whereToFind: 'Temple area sweet shops',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '6',
    name: 'Netarhat',
    category: 'Hill Station',
    description: 'Queen of Chotanagpur, famous for sunrise and sunset views.',
    image: jonhafallsImg,
    latitude: 23.4687,
    longitude: 84.2595,
    visitingHours: 'All day',
    entryFee: 'Free',
    bestTimeToVisit: 'October to May',
    highlights: ['Sunrise/sunset points', 'Cool climate', 'Magnolia Point', 'Tribal culture'],
    transport: [
      {
        id: 't9',
        type: 'bus',
        route: 'Ranchi to Netarhat',
        duration: '4-5 hours',
        cost: '₹80-120',
        frequency: '3-4 buses daily'
      }
    ],
    hotels: [
      {
        id: 'h7',
        name: 'Hill Station Resort',
        type: 'resort',
        priceRange: '₹2,800-4,200',
        rating: 4.3,
        amenities: ['Valley View', 'Bonfire', 'Restaurant', 'Trekking'],
        distance: 'City center',
        contact: '+91-6562-345678'
      }
    ],
    foods: [
      {
        id: 'f7',
        name: 'Bamboo Shoot Curry',
        description: 'Traditional tribal delicacy made from tender bamboo shoots',
        cost: '₹70-120',
        whereToFind: 'Local tribal restaurants',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '7',
    name: 'Rock Garden Ranchi',
    category: 'Garden',
    description: 'Artificial lake and rock garden created by Kanke Dam, perfect for family outings.',
    image: deoghartTempleImg,
    latitude: 23.4065,
    longitude: 85.4170,
    visitingHours: '9:00 AM - 6:00 PM',
    entryFee: '₹20 per person',
    bestTimeToVisit: 'All year round',
    highlights: ['Boating', 'Rock formations', 'Gardens', 'Photography'],
    transport: [
      {
        id: 't10',
        type: 'bus',
        route: 'Ranchi city to Rock Garden',
        duration: '45 minutes',
        cost: '₹20-35',
        frequency: 'Every 30 minutes'
      }
    ],
    hotels: [
      {
        id: 'h8',
        name: 'Garden View Hotel',
        type: 'hotel',
        priceRange: '₹1,800-2,800',
        rating: 3.7,
        amenities: ['Garden View', 'Restaurant', 'Parking'],
        distance: '2 km from garden',
        contact: '+91-651-5678901'
      }
    ],
    foods: [
      {
        id: 'f8',
        name: 'Arsa Roti',
        description: 'Sweet rice flour pancake, a traditional breakfast item',
        cost: '₹25-45',
        whereToFind: 'Garden area food stalls',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '8',
    name: 'Jagannath Temple Ranchi',
    category: 'Religious',
    description: 'Replica of famous Puri Jagannath Temple, annual Rath Yatra celebration.',
    image: rockgardenranchImg,
    latitude: 23.3569,
    longitude: 85.3350,
    visitingHours: '5:00 AM - 8:00 PM',
    entryFee: 'Free',
    bestTimeToVisit: 'All year, especially during Rath Yatra',
    highlights: ['Temple architecture', 'Rath Yatra festival', 'Spiritual atmosphere', 'Cultural events'],
    transport: [
      {
        id: 't11',
        type: 'bus',
        route: 'Main Bus Stand to Jagannath Temple',
        duration: '20 minutes',
        cost: '₹10-20',
        frequency: 'Every 15 minutes'
      }
    ],
    hotels: [
      {
        id: 'h9',
        name: 'Temple View Lodge',
        type: 'guesthouse',
        priceRange: '₹1,000-1,800',
        rating: 3.8,
        amenities: ['Temple View', 'Vegetarian Restaurant', 'Prayer Hall'],
        distance: '300m from temple',
        contact: '+91-651-6789012'
      }
    ],
    foods: [
      {
        id: 'f9',
        name: 'Kheer',
        description: 'Traditional rice pudding offered as prasad',
        cost: '₹20-40',
        whereToFind: 'Temple prasad counter',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '9',
    name: 'Patratu Valley',
    category: 'Valley',
    description: 'Scenic valley known for its dam and beautiful landscape views.',
    image: patratuvalleyImg,
    latitude: 23.6509,
    longitude: 85.1614,
    visitingHours: '6:00 AM - 7:00 PM',
    entryFee: 'Free',
    bestTimeToVisit: 'October to April',
    highlights: ['Dam views', 'Valley landscapes', 'Photography', 'Peaceful environment'],
    transport: [
      {
        id: 't12',
        type: 'bus',
        route: 'Ranchi to Patratu Valley',
        duration: '1.5 hours',
        cost: '₹35-55',
        frequency: 'Every hour'
      }
    ],
    hotels: [
      {
        id: 'h10',
        name: 'Valley Resort Patratu',
        type: 'resort',
        priceRange: '₹2,200-3,500',
        rating: 4.0,
        amenities: ['Valley View', 'Restaurant', 'Nature Walks', 'Cycling'],
        distance: '1 km from valley',
        contact: '+91-651-7890123'
      }
    ],
    foods: [
      {
        id: 'f10',
        name: 'Mahua',
        description: 'Traditional tribal drink made from Mahua flowers',
        cost: '₹40-80',
        whereToFind: 'Local tribal settlements',
        isVegetarian: true,
        specialty: true
      }
    ]
  },
  {
    id: '10',
    name: 'Hazaribagh National Park',
    category: 'National Park',
    description: 'Wildlife sanctuary known for sambar deer, wild boar, and various bird species.',
    image: hazaribaghparkImg,
    latitude: 23.9929,
    longitude: 85.3647,
    visitingHours: '6:00 AM - 6:00 PM',
    entryFee: '₹100 per person',
    bestTimeToVisit: 'November to May',
    highlights: ['Wildlife safari', 'Bird watching', 'Cantt Rock', 'Nature photography'],
    transport: [
      {
        id: 't13',
        type: 'train',
        route: 'Ranchi to Hazaribagh Road, then local transport',
        duration: '3-4 hours',
        cost: '₹100-250',
        frequency: 'Multiple trains daily'
      }
    ],
    hotels: [
      {
        id: 'h11',
        name: 'Wildlife Lodge Hazaribagh',
        type: 'guesthouse',
        priceRange: '₹1,800-2,800',
        rating: 3.9,
        amenities: ['Wildlife Tours', 'Restaurant', 'Guide Service'],
        distance: 'Near park entrance',
        contact: '+91-6546-234567'
      }
    ],
    foods: [
      {
        id: 'f11',
        name: 'Mutton Curry',
        description: 'Spicy local style mutton curry with traditional spices',
        cost: '₹120-200',
        whereToFind: 'Local restaurants near park',
        isVegetarian: false,
        specialty: true
      }
    ]
  }
];

// API simulation functions
export const getAllPlaces = (): Promise<TouristPlace[]> => {
  return new Promise((resolve) => {
    setTimeout(() => resolve(touristPlaces), 500);
  });
};

export const getPlaceById = (id: string): Promise<TouristPlace | null> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const place = touristPlaces.find(p => p.id === id);
      resolve(place || null);
    }, 300);
  });
};

export const searchPlaces = (query: string): Promise<TouristPlace[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const filtered = touristPlaces.filter(place =>
        place.name.toLowerCase().includes(query.toLowerCase()) ||
        place.category.toLowerCase().includes(query.toLowerCase()) ||
        place.description.toLowerCase().includes(query.toLowerCase())
      );
      resolve(filtered);
    }, 400);
  });
};